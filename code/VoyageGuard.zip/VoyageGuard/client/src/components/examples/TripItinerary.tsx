import TripItinerary from '../TripItinerary';

export default function TripItineraryExample() {
  const mockTrip = {
    id: "trip-1",
    title: "Golden Triangle Tour",
    duration: "7 days",
    groupSize: 4,
    locations: [
      {
        id: "loc-1",
        name: "India Gate, New Delhi",
        time: "09:00 AM",
        date: "Dec 20",
        status: "completed" as const,
        riskLevel: "safe" as const
      },
      {
        id: "loc-2", 
        name: "Taj Mahal, Agra",
        time: "11:30 AM",
        date: "Dec 21",
        status: "current" as const,
        riskLevel: "safe" as const
      },
      {
        id: "loc-3",
        name: "Hawa Mahal, Jaipur", 
        time: "02:00 PM",
        date: "Dec 22",
        status: "upcoming" as const,
        riskLevel: "caution" as const
      }
    ]
  };

  return <TripItinerary trip={mockTrip} />;
}