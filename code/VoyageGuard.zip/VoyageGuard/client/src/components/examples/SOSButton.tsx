import SOSButton from '../SOSButton';

export default function SOSButtonExample() {
  return (
    <SOSButton onSOSActivate={() => console.log('SOS activated!')} />
  );
}