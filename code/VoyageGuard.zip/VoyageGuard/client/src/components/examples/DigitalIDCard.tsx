import DigitalIDCard from '../DigitalIDCard';

export default function DigitalIDCardExample() {
  const mockProfile = {
    id: "tourist-123",
    name: "Priya Sharma",
    nationality: "Indian Citizen",
    passportNumber: "Z1234567",
    emergencyContact: {
      name: "Rajesh Sharma",
      phone: "+91 98765 43210"
    },
    tripDetails: {
      startDate: "Dec 20, 2024",
      endDate: "Dec 27, 2024", 
      purpose: "Tourism",
      destinations: ["Delhi", "Agra", "Jaipur"]
    },
    verificationStatus: "verified" as const
  };

  return <DigitalIDCard profile={mockProfile} />;
}