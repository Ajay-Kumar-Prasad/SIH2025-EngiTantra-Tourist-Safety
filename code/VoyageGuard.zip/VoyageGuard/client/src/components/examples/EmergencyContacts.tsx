import EmergencyContacts from '../EmergencyContacts';

export default function EmergencyContactsExample() {
  const mockContacts = [
    {
      id: "contact-1",
      name: "Raj Sharma",
      relation: "Father",
      phone: "+91 98765 43210",
      type: "personal" as const
    },
    {
      id: "contact-2", 
      name: "Tourist Police",
      relation: "Local Authority",
      phone: "1363",
      type: "official" as const
    },
    {
      id: "contact-3",
      name: "Apollo Hospital",
      relation: "Emergency Medical",
      phone: "+91 11 2692 5858",
      type: "medical" as const
    }
  ];

  return <EmergencyContacts contacts={mockContacts} />;
}