import InteractiveMap from '../InteractiveMap';

export default function InteractiveMapExample() {
  const mockMarkers = [
    {
      id: "marker-1",
      lat: 28.6129,
      lng: 77.2295,
      type: "current" as const,
      title: "Your Location",
      description: "India Gate, New Delhi"
    },
    {
      id: "marker-2",
      lat: 28.6139,
      lng: 77.2090,
      type: "safe" as const,
      title: "Safe Zone",
      description: "Well-lit tourist area with police presence"
    },
    {
      id: "marker-3",
      lat: 28.6289,
      lng: 77.2065,
      type: "caution" as const,
      title: "Use Caution",
      description: "Crowded market area - watch for pickpockets"
    },
    {
      id: "marker-4",
      lat: 28.6512,
      lng: 77.2410,
      type: "danger" as const,
      title: "High Risk Zone",
      description: "Recent security incidents reported"
    }
  ];

  const currentLocation = { lat: 28.6129, lng: 77.2295 };

  return <InteractiveMap markers={mockMarkers} currentLocation={currentLocation} />;
}