import RealTimeTracking from '../RealTimeTracking';

export default function RealTimeTrackingExample() {
  const mockContacts = [
    {
      id: "contact-1",
      name: "Raj Sharma",
      relation: "Father", 
      lastSeen: "2 mins ago"
    },
    {
      id: "contact-2",
      name: "Tourist Guide",
      relation: "Guide",
      lastSeen: "5 mins ago"
    }
  ];

  return (
    <RealTimeTracking 
      contacts={mockContacts}
      isEnabled={true}
      onToggle={(enabled) => console.log(`Tracking ${enabled ? 'enabled' : 'disabled'}`)}
    />
  );
}