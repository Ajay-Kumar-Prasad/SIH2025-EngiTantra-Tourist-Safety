import AppHeader from '../AppHeader';

export default function AppHeaderExample() {
  return (
    <AppHeader 
      title="Tourist Safety"
      showNotifications={true}
      notificationCount={5}
      isOnline={true}
      batteryLevel={85}
      signalStrength={3}
      onNotificationClick={() => console.log('Notifications clicked')}
    />
  );
}