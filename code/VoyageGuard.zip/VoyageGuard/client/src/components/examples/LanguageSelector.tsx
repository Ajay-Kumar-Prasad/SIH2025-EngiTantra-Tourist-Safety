import LanguageSelector from '../LanguageSelector';

export default function LanguageSelectorExample() {
  return (
    <LanguageSelector 
      onLanguageChange={(language) => console.log(`Selected language: ${language.name}`)}
    />
  );
}