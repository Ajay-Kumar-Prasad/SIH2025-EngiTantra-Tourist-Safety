import BottomNavigation from '../BottomNavigation';
import { useState } from 'react';

export default function BottomNavigationExample() {
  const [activeTab, setActiveTab] = useState("home");

  return (
    <BottomNavigation 
      activeTab={activeTab}
      onTabChange={setActiveTab}
      alertCount={3}
    />
  );
}