import IncidentAlertCard from '../IncidentAlertCard';

export default function IncidentAlertCardExample() {
  const mockAlert = {
    id: "alert-1",
    type: "security" as const,
    severity: "high" as const,
    title: "Security Alert",
    description: "Increased police activity reported in the area. Tourists advised to avoid large gatherings and stay in well-lit areas.",
    location: "Connaught Place, Central Delhi",
    timestamp: "5 minutes ago",
    affectedRadius: "500m",
    isActive: true
  };

  return (
    <IncidentAlertCard 
      alert={mockAlert}
      onDismiss={(id) => console.log(`Dismissed alert: ${id}`)}
      onViewDetails={(id) => console.log(`View details for alert: ${id}`)}
    />
  );
}