import SafetyScoreCard from '../SafetyScoreCard';

export default function SafetyScoreCardExample() {
  return (
    <SafetyScoreCard 
      score={85}
      status="safe"
      location="Mumbai, Maharashtra"
      lastUpdated="2 mins ago"
    />
  );
}