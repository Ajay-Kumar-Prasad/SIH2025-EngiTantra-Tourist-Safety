import { Phone, User, Shield, Hospital } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface EmergencyContact {
  id: string;
  name: string;
  relation: string;
  phone: string;
  type: "personal" | "official" | "medical";
}

interface EmergencyContactsProps {
  contacts: EmergencyContact[];
}

export default function EmergencyContacts({ contacts }: EmergencyContactsProps) {
  const getContactIcon = (type: string) => {
    switch (type) {
      case "personal": return <User className="w-4 h-4" />;
      case "official": return <Shield className="w-4 h-4" />;
      case "medical": return <Hospital className="w-4 h-4" />;
      default: return <Phone className="w-4 h-4" />;
    }
  };

  const getContactColor = (type: string) => {
    switch (type) {
      case "personal": return "border-l-blue-500 bg-blue-50 dark:bg-blue-950";
      case "official": return "border-l-green-500 bg-green-50 dark:bg-green-950";
      case "medical": return "border-l-red-500 bg-red-50 dark:bg-red-950";
      default: return "border-l-gray-300";
    }
  };

  const handleCall = (contact: EmergencyContact) => {
    console.log(`Calling ${contact.name} at ${contact.phone}`);
  };

  return (
    <Card data-testid="card-emergency-contacts">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          Emergency Contacts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {contacts.map((contact) => (
          <div 
            key={contact.id}
            className={`p-3 rounded-lg border-l-4 ${getContactColor(contact.type)}`}
            data-testid={`contact-${contact.id}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-background">
                  {getContactIcon(contact.type)}
                </div>
                <div>
                  <h4 className="font-medium" data-testid={`text-contact-name-${contact.id}`}>
                    {contact.name}
                  </h4>
                  <p className="text-sm text-muted-foreground" data-testid={`text-contact-relation-${contact.id}`}>
                    {contact.relation}
                  </p>
                </div>
              </div>
              <Button
                size="sm"
                onClick={() => handleCall(contact)}
                className="bg-tourist-primary hover:bg-blue-600"
                data-testid={`button-call-${contact.id}`}
              >
                <Phone className="w-4 h-4 mr-1" />
                Call
              </Button>
            </div>
            <p className="text-sm font-mono mt-2 text-muted-foreground" data-testid={`text-phone-${contact.id}`}>
              {contact.phone}
            </p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}