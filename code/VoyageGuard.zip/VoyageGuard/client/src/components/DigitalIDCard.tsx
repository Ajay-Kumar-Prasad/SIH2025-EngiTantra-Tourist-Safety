import { User, QrCode, Phone, Calendar, MapPin, Shield } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import idCardImage from "@assets/generated_images/Digital_tourist_ID_card_design_19ef150f.png";

interface TouristProfile {
  id: string;
  name: string;
  photo?: string;
  nationality: string;
  passportNumber: string;
  emergencyContact: {
    name: string;
    phone: string;
  };
  tripDetails: {
    startDate: string;
    endDate: string;
    purpose: string;
    destinations: string[];
  };
  verificationStatus: "verified" | "pending" | "unverified";
}

interface DigitalIDCardProps {
  profile: TouristProfile;
}

export default function DigitalIDCard({ profile }: DigitalIDCardProps) {
  const getVerificationBadge = () => {
    switch (profile.verificationStatus) {
      case "verified":
        return <Badge className="bg-safety-safe text-white">Verified</Badge>;
      case "pending":
        return <Badge className="bg-safety-caution text-black">Pending</Badge>;
      case "unverified":
        return <Badge className="bg-safety-danger text-white">Unverified</Badge>;
    }
  };

  return (
    <Card className="max-w-md mx-auto border-2 border-primary/20" data-testid="card-digital-id">
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <span className="font-semibold text-primary">Digital Tourist ID</span>
          </div>
          {getVerificationBadge()}
        </div>

        {/* Profile Section */}
        <div className="flex items-center gap-4 mb-4">
          <Avatar className="w-16 h-16">
            <AvatarImage src={profile.photo} />
            <AvatarFallback>
              <User className="w-8 h-8" />
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="font-semibold text-lg" data-testid="text-profile-name">
              {profile.name}
            </h3>
            <p className="text-sm text-muted-foreground" data-testid="text-nationality">
              {profile.nationality}
            </p>
            <p className="text-xs font-mono text-muted-foreground" data-testid="text-passport">
              Passport: {profile.passportNumber}
            </p>
          </div>
        </div>

        {/* Trip Details */}
        <div className="space-y-3 mb-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="flex items-center gap-1 text-muted-foreground mb-1">
                <Calendar className="w-3 h-3" />
                <span>Trip Duration</span>
              </div>
              <p className="font-medium" data-testid="text-trip-duration">
                {profile.tripDetails.startDate} - {profile.tripDetails.endDate}
              </p>
            </div>
            <div>
              <div className="flex items-center gap-1 text-muted-foreground mb-1">
                <MapPin className="w-3 h-3" />
                <span>Purpose</span>
              </div>
              <p className="font-medium" data-testid="text-trip-purpose">
                {profile.tripDetails.purpose}
              </p>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <MapPin className="w-3 h-3" />
              <span>Destinations</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {profile.tripDetails.destinations.map((dest, index) => (
                <Badge key={index} variant="secondary" className="text-xs" data-testid={`badge-destination-${index}`}>
                  {dest}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="mb-4">
          <div className="flex items-center gap-1 text-muted-foreground mb-2">
            <Phone className="w-3 h-3" />
            <span className="text-sm">Emergency Contact</span>
          </div>
          <div className="p-2 bg-muted rounded-lg">
            <p className="font-medium text-sm" data-testid="text-emergency-name">
              {profile.emergencyContact.name}
            </p>
            <p className="text-xs font-mono text-muted-foreground" data-testid="text-emergency-phone">
              {profile.emergencyContact.phone}
            </p>
          </div>
        </div>

        {/* QR Code */}
        <div className="flex justify-center">
          <div className="p-3 bg-white rounded-lg border-2 border-primary/20">
            <QrCode className="w-16 h-16 text-primary" data-testid="qr-code" />
          </div>
        </div>
        <p className="text-xs text-center text-muted-foreground mt-2">
          Scan for quick verification
        </p>
      </CardContent>
    </Card>
  );
}