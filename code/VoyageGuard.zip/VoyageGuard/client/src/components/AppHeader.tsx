import { Bell, Wifi, WifiOff, Battery, Signal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import LanguageSelector from "./LanguageSelector";

interface AppHeaderProps {
  title?: string;
  showNotifications?: boolean;
  notificationCount?: number;
  isOnline?: boolean;
  batteryLevel?: number;
  signalStrength?: number;
  onNotificationClick?: () => void;
}

export default function AppHeader({ 
  title = "Tourist Safety", 
  showNotifications = true,
  notificationCount = 0,
  isOnline = true,
  batteryLevel = 75,
  signalStrength = 4,
  onNotificationClick 
}: AppHeaderProps) {
  
  const getSignalBars = () => {
    const bars = [];
    for (let i = 1; i <= 4; i++) {
      bars.push(
        <div
          key={i}
          className={`w-1 bg-current ${
            i <= signalStrength ? "opacity-100" : "opacity-30"
          }`}
          style={{ height: `${i * 3 + 2}px` }}
        />
      );
    }
    return bars;
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border" data-testid="app-header">
      <div className="flex items-center justify-between px-4 py-3">
        {/* Left Section - Title */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">TS</span>
          </div>
          <h1 className="text-lg font-semibold" data-testid="text-app-title">{title}</h1>
        </div>

        {/* Center Section - Status Indicators */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {/* Connectivity Status */}
          <div className="flex items-center gap-1" data-testid="connectivity-status">
            {isOnline ? (
              <Wifi className="w-3 h-3 text-green-600" />
            ) : (
              <WifiOff className="w-3 h-3 text-red-500" />
            )}
          </div>

          {/* Signal Strength */}
          <div className="flex items-end gap-px h-3" data-testid="signal-strength">
            {getSignalBars()}
          </div>

          {/* Battery Level */}
          <div className="flex items-center gap-1" data-testid="battery-level">
            <Battery className={`w-3 h-3 ${
              batteryLevel > 20 ? "text-green-600" : "text-red-500"
            }`} />
            <span>{batteryLevel}%</span>
          </div>
        </div>

        {/* Right Section - Actions */}
        <div className="flex items-center gap-2">
          {/* Language Selector */}
          <LanguageSelector />

          {/* Notifications */}
          {showNotifications && (
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={onNotificationClick}
              data-testid="button-notifications"
            >
              <Bell className="w-4 h-4" />
              {notificationCount > 0 && (
                <Badge 
                  className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs bg-safety-danger text-white"
                  data-testid="badge-notification-count"
                >
                  {notificationCount > 9 ? "9+" : notificationCount}
                </Badge>
              )}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}