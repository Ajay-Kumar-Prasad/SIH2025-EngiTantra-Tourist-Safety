import { MapPin, Calendar, Clock, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface TripLocation {
  id: string;
  name: string;
  time: string;
  date: string;
  status: "upcoming" | "current" | "completed";
  riskLevel: "safe" | "caution" | "danger";
}

interface TripItineraryProps {
  trip: {
    id: string;
    title: string;
    duration: string;
    groupSize: number;
    locations: TripLocation[];
  };
}

export default function TripItinerary({ trip }: TripItineraryProps) {
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "safe": return "bg-safety-safe";
      case "caution": return "bg-safety-caution"; 
      case "danger": return "bg-safety-danger";
      default: return "bg-gray-400";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "current": return "border-l-tourist-primary bg-primary/10";
      case "completed": return "border-l-green-500 bg-green-50 dark:bg-green-950";
      case "upcoming": return "border-l-gray-300 bg-gray-50 dark:bg-gray-900";
      default: return "border-l-gray-300";
    }
  };

  return (
    <Card data-testid="card-trip-itinerary">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span data-testid="text-trip-title">{trip.title}</span>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span data-testid="text-trip-duration">{trip.duration}</span>
            <Users className="w-4 h-4 ml-2" />
            <span data-testid="text-group-size">{trip.groupSize}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {trip.locations.map((location, index) => (
          <div 
            key={location.id}
            className={`p-3 rounded-lg border-l-4 ${getStatusColor(location.status)}`}
            data-testid={`location-${location.id}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <h4 className="font-medium" data-testid={`text-location-name-${location.id}`}>
                    {location.name}
                  </h4>
                  <div className={`w-2 h-2 rounded-full ${getRiskColor(location.riskLevel)}`} />
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span data-testid={`text-date-${location.id}`}>{location.date}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span data-testid={`text-time-${location.id}`}>{location.time}</span>
                  </div>
                </div>
              </div>
              <Badge 
                variant={location.status === "current" ? "default" : "secondary"}
                data-testid={`badge-status-${location.id}`}
              >
                {location.status}
              </Badge>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}