import { Home, Map, Bell, User, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface NavigationItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  path: string;
  badge?: number;
}

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
  alertCount?: number;
}

export default function BottomNavigation({ activeTab, onTabChange, alertCount = 0 }: BottomNavigationProps) {
  const navigationItems: NavigationItem[] = [
    {
      id: "home",
      label: "Home",
      icon: <Home className="w-5 h-5" />,
      path: "/",
    },
    {
      id: "map",
      label: "Map",
      icon: <Map className="w-5 h-5" />,
      path: "/map",
    },
    {
      id: "alerts", 
      label: "Alerts",
      icon: <Bell className="w-5 h-5" />,
      path: "/alerts",
      badge: alertCount
    },
    {
      id: "profile",
      label: "Profile",
      icon: <User className="w-5 h-5" />,
      path: "/profile",
    },
    {
      id: "emergency",
      label: "SOS",
      icon: <Shield className="w-5 h-5" />,
      path: "/emergency",
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-40" data-testid="bottom-navigation">
      <div className="flex items-center justify-around px-2 py-2">
        {navigationItems.map((item) => (
          <Button
            key={item.id}
            variant={activeTab === item.id ? "default" : "ghost"}
            size="sm"
            className="flex flex-col items-center gap-1 h-auto py-2 px-3 relative"
            onClick={() => onTabChange(item.id)}
            data-testid={`nav-tab-${item.id}`}
          >
            <div className="relative">
              {item.icon}
              {item.badge && item.badge > 0 && (
                <Badge 
                  className="absolute -top-2 -right-2 h-4 w-4 p-0 text-xs bg-safety-danger text-white"
                  data-testid={`badge-${item.id}`}
                >
                  {item.badge > 9 ? "9+" : item.badge}
                </Badge>
              )}
            </div>
            <span className="text-xs font-medium">{item.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}