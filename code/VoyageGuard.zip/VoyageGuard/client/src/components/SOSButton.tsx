import { Phone, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import sosImage from "@assets/generated_images/Emergency_SOS_button_design_7476aa65.png";

interface SOSButtonProps {
  onSOSActivate?: () => void;
  isEmergency?: boolean;
}

export default function SOSButton({ onSOSActivate, isEmergency = false }: SOSButtonProps) {
  const [isActivated, setIsActivated] = useState(false);
  const [countdown, setCountdown] = useState(5);

  const handleSOSPress = () => {
    if (isActivated) return;
    
    setIsActivated(true);
    console.log('SOS button pressed - Emergency services contacted');
    
    // Simulate countdown
    let count = 5;
    const timer = setInterval(() => {
      count--;
      setCountdown(count);
      if (count === 0) {
        clearInterval(timer);
        onSOSActivate?.();
        console.log('Emergency alert sent to authorities and emergency contacts');
      }
    }, 1000);
  };

  if (isActivated) {
    return (
      <div className="fixed bottom-6 right-6 z-50" data-testid="sos-activated">
        <div className="bg-safety-danger text-white p-4 rounded-lg shadow-lg max-w-xs">
          <div className="flex items-center gap-2 mb-2">
            <div className="animate-pulse">
              <Phone className="w-5 h-5" />
            </div>
            <span className="font-semibold">Emergency Alert Activated</span>
          </div>
          <p className="text-sm mb-2">Contacting authorities in {countdown}s...</p>
          <div className="flex items-center gap-2 text-xs">
            <MapPin className="w-3 h-3" />
            <span>Location shared automatically</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Button
        size="icon"
        className="w-16 h-16 rounded-full bg-safety-danger hover:bg-red-600 border-4 border-white shadow-lg animate-pulse"
        onClick={handleSOSPress}
        data-testid="button-sos"
      >
        <div className="flex flex-col items-center">
          <Phone className="w-6 h-6 text-white" />
          <span className="text-xs font-bold text-white">SOS</span>
        </div>
      </Button>
      
      {!isEmergency && (
        <div className="absolute -top-12 -left-8 bg-black/80 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
          Tap for emergency
        </div>
      )}
    </div>
  );
}