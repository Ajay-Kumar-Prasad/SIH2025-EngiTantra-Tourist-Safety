import { Shield, TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface SafetyScoreCardProps {
  score: number;
  status: "safe" | "caution" | "danger";
  location: string;
  lastUpdated: string;
}

export default function SafetyScoreCard({ score, status, location, lastUpdated }: SafetyScoreCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case "safe": return "bg-safety-safe text-white";
      case "caution": return "bg-safety-caution text-black";
      case "danger": return "bg-safety-danger text-white";
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case "safe": return <TrendingUp className="w-4 h-4" />;
      case "caution": return <Shield className="w-4 h-4" />;
      case "danger": return <TrendingDown className="w-4 h-4" />;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case "safe": return "Safe Zone";
      case "caution": return "Use Caution";
      case "danger": return "High Risk";
    }
  };

  return (
    <Card className="border-2 hover-elevate" data-testid="card-safety-score">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-full ${getStatusColor()}`}>
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-semibold" data-testid="text-safety-title">Tourist Safety Score</h3>
              <p className="text-sm text-muted-foreground" data-testid="text-location">{location}</p>
            </div>
          </div>
          <Badge className={`${getStatusColor()} flex items-center gap-1`} data-testid="badge-status">
            {getStatusIcon()}
            {getStatusText()}
          </Badge>
        </div>
        
        <div className="flex items-end gap-2 mb-2">
          <span className="text-4xl font-bold" data-testid="text-score">{score}</span>
          <span className="text-lg text-muted-foreground">/100</span>
        </div>
        
        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
          <div 
            className={`h-full transition-all duration-300 ${
              status === "safe" ? "bg-safety-safe" :
              status === "caution" ? "bg-safety-caution" : "bg-safety-danger"
            }`}
            style={{ width: `${score}%` }}
          />
        </div>
        
        <p className="text-xs text-muted-foreground mt-2" data-testid="text-last-updated">
          Last updated: {lastUpdated}
        </p>
      </CardContent>
    </Card>
  );
}