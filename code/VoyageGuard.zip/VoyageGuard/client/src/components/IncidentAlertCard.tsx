import { AlertTriangle, Clock, MapPin, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface IncidentAlert {
  id: string;
  type: "security" | "medical" | "weather" | "traffic";
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  description: string;
  location: string;
  timestamp: string;
  affectedRadius: string;
  isActive: boolean;
}

interface IncidentAlertCardProps {
  alert: IncidentAlert;
  onDismiss?: (id: string) => void;
  onViewDetails?: (id: string) => void;
}

export default function IncidentAlertCard({ alert, onDismiss, onViewDetails }: IncidentAlertCardProps) {
  const getSeverityColor = () => {
    switch (alert.severity) {
      case "low": return "border-l-green-500 bg-green-50 dark:bg-green-950";
      case "medium": return "border-l-yellow-500 bg-yellow-50 dark:bg-yellow-950";
      case "high": return "border-l-orange-500 bg-orange-50 dark:bg-orange-950";
      case "critical": return "border-l-red-500 bg-red-50 dark:bg-red-950";
      default: return "border-l-gray-300";
    }
  };

  const getSeverityBadgeColor = () => {
    switch (alert.severity) {
      case "low": return "bg-safety-safe text-white";
      case "medium": return "bg-safety-caution text-black";
      case "high": return "bg-orange-500 text-white";
      case "critical": return "bg-safety-danger text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const getTypeIcon = () => {
    switch (alert.type) {
      case "security": return <AlertTriangle className="w-4 h-4" />;
      case "medical": return <Users className="w-4 h-4" />;
      case "weather": return <AlertTriangle className="w-4 h-4" />;
      case "traffic": return <MapPin className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  return (
    <Card className={`border-l-4 ${getSeverityColor()}`} data-testid={`card-incident-${alert.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-background">
              {getTypeIcon()}
            </div>
            <div>
              <h4 className="font-medium" data-testid={`text-alert-title-${alert.id}`}>
                {alert.title}
              </h4>
              <div className="flex items-center gap-2 mt-1">
                <Badge className={getSeverityBadgeColor()} data-testid={`badge-severity-${alert.id}`}>
                  {alert.severity.toUpperCase()}
                </Badge>
                {alert.isActive && (
                  <Badge variant="outline" className="animate-pulse" data-testid={`badge-active-${alert.id}`}>
                    ACTIVE
                  </Badge>
                )}
              </div>
            </div>
          </div>
          {onDismiss && (
            <Button
              size="icon"
              variant="ghost"
              className="h-8 w-8"
              onClick={() => onDismiss(alert.id)}
              data-testid={`button-dismiss-${alert.id}`}
            >
              ×
            </Button>
          )}
        </div>

        <p className="text-sm text-muted-foreground mb-3" data-testid={`text-description-${alert.id}`}>
          {alert.description}
        </p>

        <div className="space-y-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <MapPin className="w-3 h-3" />
            <span data-testid={`text-location-${alert.id}`}>{alert.location}</span>
            <span className="text-primary" data-testid={`text-radius-${alert.id}`}>
              ({alert.affectedRadius} radius)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-3 h-3" />
            <span data-testid={`text-timestamp-${alert.id}`}>{alert.timestamp}</span>
          </div>
        </div>

        {onViewDetails && (
          <div className="mt-3 pt-3 border-t">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onViewDetails(alert.id)}
              data-testid={`button-view-details-${alert.id}`}
            >
              View Details
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}