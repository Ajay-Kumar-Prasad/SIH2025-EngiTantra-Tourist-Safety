import { MapPin, AlertTriangle, Shield, Navigation } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { Map, Marker } from "pigeon-maps";

interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  type: "current" | "safe" | "caution" | "danger" | "incident";
  title: string;
  description?: string;
}

interface InteractiveMapProps {
  markers: MapMarker[];
  currentLocation: { lat: number; lng: number };
}

export default function InteractiveMap({ markers, currentLocation }: InteractiveMapProps) {
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);
  const [mapView, setMapView] = useState<"street" | "satellite">("street");

  const getMarkerIcon = (type: string) => {
    switch (type) {
      case "current": return <Navigation className="w-4 h-4 text-blue-600" />;
      case "safe": return <Shield className="w-4 h-4 text-green-600" />;
      case "caution": return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case "danger": return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case "incident": return <AlertTriangle className="w-4 h-4 text-red-800" />;
      default: return <MapPin className="w-4 h-4" />;
    }
  };

  const getMarkerColor = (type: string) => {
    switch (type) {
      case "current": return "bg-blue-100 border-blue-500";
      case "safe": return "bg-green-100 border-green-500";
      case "caution": return "bg-yellow-100 border-yellow-500";
      case "danger": return "bg-red-100 border-red-500";
      case "incident": return "bg-red-200 border-red-700";
      default: return "bg-gray-100 border-gray-500";
    }
  };

  const [zoom, setZoom] = useState(13);

  const getTileProvider = () => {
    if (mapView === "satellite") {
      // Satellite imagery from Esri
      return (x: number, y: number, z: number) => 
        `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`;
    } else {
      // OpenStreetMap tiles
      return (x: number, y: number, z: number) => 
        `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
    }
  };

  const CustomMarker = ({ marker }: { marker: MapMarker }) => (
    <div
      className={`w-8 h-8 rounded-full border-2 cursor-pointer hover-elevate ${getMarkerColor(marker.type)} shadow-lg`}
      onClick={() => setSelectedMarker(marker)}
      data-testid={`marker-${marker.id}`}
    >
      <div className="flex items-center justify-center w-full h-full">
        {getMarkerIcon(marker.type)}
      </div>
    </div>
  );

  return (
    <Card className="h-96 shadow-lg border-2" data-testid="card-interactive-map">
      <CardContent className="p-0 h-full relative">
        {/* Real Interactive Map */}
        <div className="w-full h-full relative overflow-hidden rounded-lg">
          <Map
            height={384} // h-96 = 384px
            center={[currentLocation.lat, currentLocation.lng]}
            zoom={zoom}
            provider={getTileProvider()}
            onBoundsChanged={({ zoom: newZoom }) => setZoom(newZoom)}
            attribution={false}
          >
            {/* Current Location Marker */}
            <Marker 
              anchor={[currentLocation.lat, currentLocation.lng]} 
              color="#3b82f6"
              data-testid="current-location-marker"
            />

            {/* Safety Zone Markers */}
            {markers.map((marker) => (
              <Marker
                key={marker.id}
                anchor={[marker.lat, marker.lng]}
                payload={marker}
                onClick={() => setSelectedMarker(marker)}
              >
                <CustomMarker marker={marker} />
              </Marker>
            ))}
          </Map>

          {/* Map Controls */}
          <div className="absolute top-4 right-4 z-10 space-y-2 bg-white/90 dark:bg-black/90 p-2 rounded-lg shadow-md">
            <Button
              size="sm"
              variant={mapView === "street" ? "default" : "outline"}
              onClick={() => setMapView("street")}
              data-testid="button-street-view"
            >
              Street
            </Button>
            <Button
              size="sm"
              variant={mapView === "satellite" ? "default" : "outline"}
              onClick={() => setMapView("satellite")}
              data-testid="button-satellite-view"
            >
              Satellite
            </Button>
          </div>

          {/* Selected Marker Info */}
          {selectedMarker && (
            <div className="absolute bottom-4 left-4 bg-white dark:bg-card p-4 rounded-lg shadow-lg max-w-xs z-20" data-testid="marker-info">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-medium" data-testid="text-marker-title">{selectedMarker.title}</h4>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-6 w-6"
                  onClick={() => setSelectedMarker(null)}
                  data-testid="button-close-marker-info"
                >
                  ×
                </Button>
              </div>
              {selectedMarker.description && (
                <p className="text-sm text-muted-foreground mb-2" data-testid="text-marker-description">
                  {selectedMarker.description}
                </p>
              )}
              <Badge className={getMarkerColor(selectedMarker.type)} data-testid="badge-marker-type">
                {selectedMarker.type}
              </Badge>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}