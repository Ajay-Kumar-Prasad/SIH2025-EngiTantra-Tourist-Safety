import { MapPin, Eye, EyeOff, Users, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

interface TrackingContact {
  id: string;
  name: string;
  relation: string;
  lastSeen: string;
}

interface RealTimeTrackingProps {
  contacts: TrackingContact[];
  isEnabled?: boolean;
  onToggle?: (enabled: boolean) => void;
}

export default function RealTimeTracking({ contacts, isEnabled = false, onToggle }: RealTimeTrackingProps) {
  const [trackingEnabled, setTrackingEnabled] = useState(isEnabled);

  const handleToggle = (enabled: boolean) => {
    setTrackingEnabled(enabled);
    onToggle?.(enabled);
    console.log(`Real-time tracking ${enabled ? 'enabled' : 'disabled'}`);
  };

  return (
    <Card data-testid="card-real-time-tracking">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-primary" />
            Real-Time Tracking
          </div>
          <div className="flex items-center gap-2">
            <Switch
              checked={trackingEnabled}
              onCheckedChange={handleToggle}
              data-testid="switch-tracking"
            />
            {trackingEnabled ? (
              <Eye className="w-4 h-4 text-green-600" />
            ) : (
              <EyeOff className="w-4 h-4 text-gray-400" />
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {trackingEnabled ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950 rounded-lg">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm font-medium text-green-700 dark:text-green-300">
                Location sharing is active
              </span>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <Users className="w-4 h-4" />
                Sharing with ({contacts.length})
              </h4>
              {contacts.map((contact) => (
                <div 
                  key={contact.id}
                  className="flex items-center justify-between p-2 border rounded-lg"
                  data-testid={`tracking-contact-${contact.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                      <Users className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium" data-testid={`text-contact-name-${contact.id}`}>
                        {contact.name}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid={`text-contact-relation-${contact.id}`}>
                        {contact.relation}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span data-testid={`text-last-seen-${contact.id}`}>{contact.lastSeen}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-xs text-muted-foreground mt-4 p-2 bg-muted rounded-lg">
              Your location is updated every 30 seconds. Emergency contacts can see your exact location.
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <EyeOff className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground mb-2">
              Location sharing is disabled
            </p>
            <p className="text-xs text-muted-foreground">
              Enable to share your location with emergency contacts for safety
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}