import SafetyScoreCard from "@/components/SafetyScoreCard";
import TripItinerary from "@/components/TripItinerary";
import EmergencyContacts from "@/components/EmergencyContacts";
import RealTimeTracking from "@/components/RealTimeTracking";
import SOSButton from "@/components/SOSButton";
import heroImage from "@assets/generated_images/Tourist_safety_app_hero_illustration_f6dba884.png";

export default function HomePage() {
  // todo: remove mock data functionality - replace with real API calls
  const mockTrip = {
    id: "trip-1",
    title: "Golden Triangle Tour",
    duration: "7 days",
    groupSize: 4,
    locations: [
      {
        id: "loc-1",
        name: "India Gate, New Delhi",
        time: "09:00 AM",
        date: "Dec 20",
        status: "completed" as const,
        riskLevel: "safe" as const
      },
      {
        id: "loc-2", 
        name: "Taj Mahal, Agra",
        time: "11:30 AM",
        date: "Dec 21",
        status: "current" as const,
        riskLevel: "safe" as const
      },
      {
        id: "loc-3",
        name: "Hawa Mahal, Jaipur", 
        time: "02:00 PM",
        date: "Dec 22",
        status: "upcoming" as const,
        riskLevel: "caution" as const
      }
    ]
  };

  const mockContacts = [
    {
      id: "contact-1",
      name: "Raj Sharma",
      relation: "Father",
      phone: "+91 98765 43210",
      type: "personal" as const
    },
    {
      id: "contact-2", 
      name: "Tourist Police",
      relation: "Local Authority",
      phone: "1363",
      type: "official" as const
    },
    {
      id: "contact-3",
      name: "Apollo Hospital",
      relation: "Emergency Medical",
      phone: "+91 11 2692 5858",
      type: "medical" as const
    }
  ];

  const mockTrackingContacts = [
    {
      id: "track-1",
      name: "Raj Sharma",
      relation: "Father", 
      lastSeen: "2 mins ago"
    },
    {
      id: "track-2",
      name: "Tourist Guide",
      relation: "Guide",
      lastSeen: "5 mins ago"
    }
  ];

  return (
    <div className="min-h-screen bg-tourist-background pb-20" data-testid="page-home">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative px-4 py-8">
          <div className="max-w-md mx-auto text-center">
            <img 
              src={heroImage} 
              alt="Tourist Safety App" 
              className="w-full h-32 object-cover rounded-lg mb-4 opacity-80"
            />
            <h2 className="text-xl font-bold mb-2">Stay Safe, Travel Smart</h2>
            <p className="text-sm text-primary-foreground/90">
              Your companion for safe tourism across India
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-6 space-y-6 max-w-md mx-auto">
        {/* Safety Score */}
        <SafetyScoreCard 
          score={85}
          status="safe"
          location="Mumbai, Maharashtra"
          lastUpdated="2 mins ago"
        />

        {/* Trip Itinerary */}
        <TripItinerary trip={mockTrip} />

        {/* Real-Time Tracking */}
        <RealTimeTracking 
          contacts={mockTrackingContacts}
          isEnabled={true}
          onToggle={(enabled) => console.log(`Tracking ${enabled ? 'enabled' : 'disabled'}`)}
        />

        {/* Emergency Contacts */}
        <EmergencyContacts contacts={mockContacts} />
      </div>

      {/* Floating SOS Button */}
      <SOSButton onSOSActivate={() => console.log('Emergency services contacted!')} />
    </div>
  );
}