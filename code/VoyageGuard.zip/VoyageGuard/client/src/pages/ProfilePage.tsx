import DigitalIDCard from "@/components/DigitalIDCard";
import SOSButton from "@/components/SOSButton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  User, 
  Shield, 
  Bell, 
  Eye, 
  Download, 
  Share, 
  Settings,
  Database,
  Trash2
} from "lucide-react";
import { useState } from "react";

export default function ProfilePage() {
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);
  const [dataCollection, setDataCollection] = useState(true);

  // todo: remove mock data functionality - replace with real user profile API
  const mockProfile = {
    id: "tourist-123",
    name: "Priya Sharma",
    nationality: "Indian Citizen",
    passportNumber: "Z1234567",
    emergencyContact: {
      name: "Rajesh Sharma",
      phone: "+91 98765 43210"
    },
    tripDetails: {
      startDate: "Dec 20, 2024",
      endDate: "Dec 27, 2024", 
      purpose: "Tourism",
      destinations: ["Delhi", "Agra", "Jaipur"]
    },
    verificationStatus: "verified" as const
  };

  const dataPermissions = [
    {
      id: "location",
      title: "Location Data",
      description: "Used for safety alerts and emergency response",
      grantor: "Tourist Safety App",
      granted: "Dec 20, 2024",
      canRevoke: true
    },
    {
      id: "contacts",
      title: "Emergency Contacts",
      description: "Shared with local authorities during emergencies",
      grantor: "Local Police",
      granted: "Dec 20, 2024",
      canRevoke: false
    },
    {
      id: "itinerary",
      title: "Travel Itinerary",
      description: "Used to provide location-specific safety information",
      grantor: "Tourism Board",
      granted: "Dec 19, 2024",
      canRevoke: true
    }
  ];

  return (
    <div className="min-h-screen bg-background pb-20" data-testid="page-profile">
      {/* Header */}
      <div className="px-4 py-4 border-b">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            Tourist Profile
          </h1>
          <Button variant="ghost" size="icon" data-testid="button-profile-settings">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-6 max-w-md mx-auto">
        {/* Digital ID Card */}
        <DigitalIDCard profile={mockProfile} />

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => console.log('Download ID clicked')}
              data-testid="button-download-id"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Digital ID
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => console.log('Share ID clicked')}
              data-testid="button-share-id"
            >
              <Share className="w-4 h-4 mr-2" />
              Share with Guide
            </Button>
          </CardContent>
        </Card>

        {/* Privacy Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Privacy & Permissions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Push Notifications</p>
                <p className="text-xs text-muted-foreground">Receive safety alerts</p>
              </div>
              <Switch
                checked={notifications}
                onCheckedChange={setNotifications}
                data-testid="switch-notifications"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Location Sharing</p>
                <p className="text-xs text-muted-foreground">Share with emergency contacts</p>
              </div>
              <Switch
                checked={locationSharing}
                onCheckedChange={setLocationSharing}
                data-testid="switch-location-sharing"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Data Collection</p>
                <p className="text-xs text-muted-foreground">Improve safety recommendations</p>
              </div>
              <Switch
                checked={dataCollection}
                onCheckedChange={setDataCollection}
                data-testid="switch-data-collection"
              />
            </div>
          </CardContent>
        </Card>

        {/* Consent Dashboard */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Database className="w-4 h-4" />
              Data Permissions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {dataPermissions.map((permission) => (
              <div 
                key={permission.id}
                className="p-3 border rounded-lg"
                data-testid={`permission-${permission.id}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium" data-testid={`text-permission-title-${permission.id}`}>
                      {permission.title}
                    </h4>
                    <p className="text-xs text-muted-foreground" data-testid={`text-permission-description-${permission.id}`}>
                      {permission.description}
                    </p>
                  </div>
                  {permission.canRevoke ? (
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => console.log(`Revoke permission: ${permission.id}`)}
                      data-testid={`button-revoke-${permission.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  ) : (
                    <Badge variant="secondary" className="text-xs">Required</Badge>
                  )}
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span data-testid={`text-grantor-${permission.id}`}>
                    Granted to: {permission.grantor}
                  </span>
                  <span data-testid={`text-granted-date-${permission.id}`}>
                    {permission.granted}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Floating SOS Button */}
      <SOSButton onSOSActivate={() => console.log('Emergency services contacted!')} />
    </div>
  );
}