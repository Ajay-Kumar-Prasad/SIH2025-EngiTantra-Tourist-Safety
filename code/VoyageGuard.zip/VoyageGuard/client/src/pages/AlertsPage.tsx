import IncidentAlertCard from "@/components/IncidentAlertCard";
import SOSButton from "@/components/SOSButton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Filter, Settings } from "lucide-react";
import { useState } from "react";

export default function AlertsPage() {
  const [filter, setFilter] = useState<"all" | "active" | "dismissed">("all");

  // todo: remove mock data functionality - replace with real alert API calls
  const mockAlerts = [
    {
      id: "alert-1",
      type: "security" as const,
      severity: "high" as const,
      title: "Security Alert",
      description: "Increased police activity reported in the area. Tourists advised to avoid large gatherings and stay in well-lit areas.",
      location: "Connaught Place, Central Delhi",
      timestamp: "5 minutes ago",
      affectedRadius: "500m",
      isActive: true
    },
    {
      id: "alert-2",
      type: "weather" as const,
      severity: "medium" as const,
      title: "Weather Advisory",
      description: "Heavy rainfall expected in the next 2 hours. Plan indoor activities and avoid low-lying areas.",
      location: "Mumbai Metropolitan Area",
      timestamp: "15 minutes ago",
      affectedRadius: "10km",
      isActive: true
    },
    {
      id: "alert-3",
      type: "traffic" as const,
      severity: "low" as const,
      title: "Traffic Update",
      description: "Road closure due to construction work. Alternative routes available via Ring Road.",
      location: "Karol Bagh, New Delhi",
      timestamp: "30 minutes ago",
      affectedRadius: "2km",
      isActive: false
    },
    {
      id: "alert-4",
      type: "medical" as const,
      severity: "critical" as const,
      title: "Health Emergency",
      description: "Food poisoning incidents reported at local street food vendors. Stick to bottled water and cooked meals.",
      location: "Chandni Chowk, Old Delhi",
      timestamp: "1 hour ago",
      affectedRadius: "1km",
      isActive: true
    }
  ];

  const getFilteredAlerts = () => {
    switch (filter) {
      case "active":
        return mockAlerts.filter(alert => alert.isActive);
      case "dismissed":
        return mockAlerts.filter(alert => !alert.isActive);
      default:
        return mockAlerts;
    }
  };

  const activeCount = mockAlerts.filter(alert => alert.isActive).length;

  return (
    <div className="min-h-screen bg-background pb-20" data-testid="page-alerts">
      {/* Header */}
      <div className="px-4 py-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            Safety Alerts
          </h1>
          <Button variant="ghost" size="icon" data-testid="button-alert-settings">
            <Settings className="w-4 h-4" />
          </Button>
        </div>

        {/* Summary Card */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Alerts</p>
                <p className="text-2xl font-bold" data-testid="text-active-count">{activeCount}</p>
              </div>
              <Badge 
                className={`${activeCount > 0 ? 'bg-safety-danger text-white animate-pulse' : 'bg-safety-safe text-white'}`}
                data-testid="badge-alert-status"
              >
                {activeCount > 0 ? `${activeCount} Active` : 'All Clear'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Filter Buttons */}
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
            data-testid="filter-all"
          >
            All ({mockAlerts.length})
          </Button>
          <Button
            size="sm"
            variant={filter === "active" ? "default" : "outline"}
            onClick={() => setFilter("active")}
            data-testid="filter-active"
          >
            Active ({activeCount})
          </Button>
          <Button
            size="sm"
            variant={filter === "dismissed" ? "default" : "outline"}
            onClick={() => setFilter("dismissed")}
            data-testid="filter-dismissed"
          >
            Dismissed ({mockAlerts.length - activeCount})
          </Button>
        </div>
      </div>

      {/* Alerts List */}
      <div className="p-4 space-y-4 max-w-md mx-auto">
        {getFilteredAlerts().length > 0 ? (
          getFilteredAlerts().map((alert) => (
            <IncidentAlertCard
              key={alert.id}
              alert={alert}
              onDismiss={(id) => console.log(`Dismissed alert: ${id}`)}
              onViewDetails={(id) => console.log(`View details for alert: ${id}`)}
            />
          ))
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <Bell className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                No alerts to display
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Floating SOS Button */}
      <SOSButton onSOSActivate={() => console.log('Emergency services contacted!')} />
    </div>
  );
}