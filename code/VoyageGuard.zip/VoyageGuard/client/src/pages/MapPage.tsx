import InteractiveMap from "@/components/InteractiveMap";
import IncidentAlertCard from "@/components/IncidentAlertCard";
import SOSButton from "@/components/SOSButton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, AlertTriangle } from "lucide-react";

export default function MapPage() {
  // todo: remove mock data functionality - replace with real map API integration
  const mockMarkers = [
    {
      id: "marker-1",
      lat: 28.6129,
      lng: 77.2295,
      type: "current" as const,
      title: "Your Location",
      description: "India Gate, New Delhi"
    },
    {
      id: "marker-2",
      lat: 28.6139,
      lng: 77.2090,
      type: "safe" as const,
      title: "Safe Zone",
      description: "Well-lit tourist area with police presence"
    },
    {
      id: "marker-3",
      lat: 28.6289,
      lng: 77.2065,
      type: "caution" as const,
      title: "Use Caution",
      description: "Crowded market area - watch for pickpockets"
    },
    {
      id: "marker-4",
      lat: 28.6512,
      lng: 77.2410,
      type: "danger" as const,
      title: "High Risk Zone",
      description: "Recent security incidents reported"
    },
    {
      id: "marker-5",
      lat: 28.6012,
      lng: 77.2190,
      type: "incident" as const,
      title: "Active Incident",
      description: "Traffic accident - road blocked"
    }
  ];

  const currentLocation = { lat: 28.6129, lng: 77.2295 };

  const activeAlert = {
    id: "map-alert-1",
    type: "security" as const,
    severity: "medium" as const,
    title: "Crowded Area Alert",
    description: "High tourist density detected in your vicinity. Keep belongings secure and stay aware of surroundings.",
    location: "Connaught Place, Central Delhi",
    timestamp: "3 minutes ago",
    affectedRadius: "200m",
    isActive: true
  };

  return (
    <div className="min-h-screen bg-background pb-20" data-testid="page-map">
      {/* Header */}
      <div className="px-4 py-4 border-b">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <MapPin className="w-5 h-5 text-primary" />
            Live Safety Map
          </h1>
          <Badge className="bg-green-100 text-green-800 border-green-300">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1" />
            Live
          </Badge>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-4xl mx-auto">
        {/* Interactive Map */}
        <InteractiveMap markers={mockMarkers} currentLocation={currentLocation} />

        {/* Legend */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Map Legend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full" />
                <span>Your Location</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
                <span>Safe Zone</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                <span>Use Caution</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                <span>High Risk</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active Area Alert */}
        <div className="space-y-2">
          <h3 className="text-sm font-medium flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
            Area Alerts
          </h3>
          <IncidentAlertCard 
            alert={activeAlert}
            onDismiss={(id) => console.log(`Dismissed alert: ${id}`)}
            onViewDetails={(id) => console.log(`View details for alert: ${id}`)}
          />
        </div>
      </div>

      {/* Floating SOS Button */}
      <SOSButton onSOSActivate={() => console.log('Emergency services contacted!')} />
    </div>
  );
}