import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState } from "react";

// Pages
import HomePage from "@/pages/HomePage";
import MapPage from "@/pages/MapPage";
import AlertsPage from "@/pages/AlertsPage";
import ProfilePage from "@/pages/ProfilePage";
import NotFound from "@/pages/not-found";

// Components
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/map" component={MapPage} />
      <Route path="/alerts" component={AlertsPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/emergency" component={HomePage} /> {/* Redirect to home with SOS visible */}
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [notificationCount] = useState(5); // todo: remove mock data - get from real notification API
  const [alertCount] = useState(3); // todo: remove mock data - get from real alert API

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    // Navigate to the corresponding route
    const routes = {
      home: "/",
      map: "/map", 
      alerts: "/alerts",
      profile: "/profile",
      emergency: "/"
    };
    
    const route = routes[tabId as keyof typeof routes];
    if (route) {
      window.history.pushState({}, "", route);
      // Trigger a popstate event to update wouter
      window.dispatchEvent(new PopStateEvent("popstate"));
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background">
          {/* App Header */}
          <AppHeader 
            title="Tourist Safety"
            showNotifications={true}
            notificationCount={notificationCount}
            isOnline={true}
            batteryLevel={85}
            signalStrength={3}
            onNotificationClick={() => console.log('Notifications clicked')}
          />

          {/* Main Content */}
          <main className="relative">
            <Router />
          </main>

          {/* Bottom Navigation */}
          <BottomNavigation 
            activeTab={activeTab}
            onTabChange={handleTabChange}
            alertCount={alertCount}
          />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}