# Smart Tourist Safety App - Design Guidelines

## Design Approach
**Selected Approach:** Reference-Based (Safety & Travel Apps)
Drawing inspiration from Google Maps, Zomato, and emergency service apps, prioritizing clarity, trust, and immediate accessibility for safety-critical information.

## Core Design Elements

### Color Palette
**Safety-First Color System:**
- **Primary Brand:** 220 85% 45% (Deep Blue - trust/security)
- **Safety Status Colors:**
  - Green (Safe): 142 69% 58%
  - Yellow (Caution): 48 96% 53%
  - Red (Danger): 0 84% 60%
- **Dark Mode:** 220 15% 12% backgrounds with 220 10% 85% text
- **Accent (minimal use):** 280 65% 60% (Purple for premium features)

### Typography
- **Primary:** Inter (Google Fonts) - excellent readability for safety information
- **Secondary:** Noto Sans (for Indian language support)
- **Hierarchy:** Bold weights for alerts/status, regular for body text

### Layout System
**Tailwind Spacing:** Consistent use of 2, 4, 6, 8 units
- Cards: p-6, m-4
- Buttons: px-6 py-3
- Sections: space-y-8

### Component Library

**Core Components:**
- **Safety Score Card:** Large, prominent display with color-coded background
- **SOS Button:** Fixed bottom-right, red gradient, extra-large touch target
- **Alert Cards:** Color-coded borders matching safety levels
- **Location Cards:** Clean white/dark cards with map integration
- **Status Indicators:** Dot indicators with labels
- **Navigation:** Bottom tab bar for mobile, side nav for desktop

**Navigation Structure:**
- Home (Safety Dashboard)
- Map (Interactive with risk zones)
- Alerts (Incident notifications)
- Profile (Tourist ID & settings)
- Emergency (SOS & contacts)

### Mobile-First Responsive Design
- **Primary:** 375px mobile viewport
- **Secondary:** 768px tablet, 1024px desktop
- **Touch Targets:** Minimum 44px for safety-critical elements
- **Thumb Zones:** SOS button and key actions in easy reach

### Safety-Specific UI Patterns
- **Emergency Actions:** Always visible, high contrast
- **Status Communication:** Icons + text + color coding
- **Quick Access:** Swipe gestures for emergency features
- **Offline Indicators:** Clear visual feedback for connectivity

### Language Support
- **Toggle:** Top-right language switcher
- **RTL Support:** Flexible layouts for Indian languages
- **Font Scaling:** Responsive text sizing for readability

### Interactive Elements
- **Real-time Updates:** Subtle pulse animations for live data
- **Location Sharing:** Visual feedback for GPS accuracy
- **Voice Commands:** Microphone icon with speaking state
- **Panic Mode:** Screen flash/vibration feedback

This design prioritizes user safety through clear visual hierarchy, immediate access to emergency features, and culturally appropriate design patterns for Indian users.